﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizApp
{
    public partial class _8thQuestionForm : Form
    {
        public _8thQuestionForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            _5thQuestionForm form = new _5thQuestionForm();
            if (textBox1.Text == "1,2 HS" && textBox2.Text == "3 Simp" && textBox3.Text == "5 Add") 
            {
                MessageBox.Show("Your score is now 8", " Your answer is correct!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                DialogResult dialogResult = MessageBox.Show("Your Answer is Wrong!", "Do you want to continue?", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
                if (dialogResult == DialogResult.Yes)
                {
                    Hide();
                    form.Show();
                }
                else if (dialogResult == DialogResult.No)
                {
                    MessageBox.Show("Your Final Score is 7");
                }
            }
        }
        

        private void button2_Click(object sender, EventArgs e)
        {
            Instructions instform = new Instructions();
            instform.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void _8thQuestionForm_Load(object sender, EventArgs e)
        {

        }
    }
}
