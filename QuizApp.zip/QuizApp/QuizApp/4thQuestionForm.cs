﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizApp
{
    public partial class _4thQuestionForm : Form
    {
        public _4thQuestionForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            _4thQuestionForm form = new _4thQuestionForm();
            if (textBox1.Text == "1,3 MT" && textBox2.Text == "2,5 DS" && textBox3.Text == "4,6 MP" && textBox2.Text == "1,7 HS") 
            {
                MessageBox.Show("Your score is now 4", " Your answer is correct!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                DialogResult dialogResult = MessageBox.Show("Your Answer is Wrong!", "Do you want to continue?", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
                if (dialogResult == DialogResult.Yes)
                {
                    Hide();
                    form.Show();
                }
                else if (dialogResult == DialogResult.No)
                {
                    MessageBox.Show("Your Final Score is 3");
                }
            }
        }
        

        private void button2_Click(object sender, EventArgs e)
        {
            Instructions instform = new Instructions();
            instform.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
