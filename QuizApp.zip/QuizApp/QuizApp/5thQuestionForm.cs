﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizApp
{
    public partial class _5thQuestionForm : Form
    {
        public _5thQuestionForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            _5thQuestionForm form = new _5thQuestionForm();
            if (textBox1.Text == "3,4 MT" && textBox2.Text == "5,2 MP" && textBox3.Text == "6,1 DS") 
            {
                MessageBox.Show("Your score is now 5", " Your answer is correct!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                DialogResult dialogResult = MessageBox.Show("Your Answer is Wrong!", "Do you want to continue?", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
                if (dialogResult == DialogResult.Yes)
                {
                    Hide();
                    form.Show();
                }
                else if (dialogResult == DialogResult.No)
                {
                    MessageBox.Show("Your Final Score is 4");
                }
            }
        }
        

        private void button2_Click(object sender, EventArgs e)
        {
            Instructions instform = new Instructions();
            instform.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
